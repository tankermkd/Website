# html-jumpscare
Web jumpscare with redirect and fullscreen toggle
